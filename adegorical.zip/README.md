# advanced-categorical
advanced categorical transformations for data analysis in python
